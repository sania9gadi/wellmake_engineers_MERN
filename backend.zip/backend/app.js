const express = require('express');
const cors = require('cors');
const connectDB = require('./db/connect');
const adminRoutes = require('./routes/adminRoutes');

const userRoutes = require('./routes/userRoutes');
const inquiryRoutes = require('./routes/inquiryRoutes');
const app = express();
app.use(express.json());
app.use(cors());


app.use('/api/admin', adminRoutes);
app.use('/api/user', userRoutes); 
app.use('/api/inquiry', inquiryRoutes);
const PORT = 9000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
