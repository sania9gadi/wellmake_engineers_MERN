const validateInquiryData = (req, res, next) => {
  const { name, email, product } = req.body;

  if (!name || !email || !product) {
    return res.status(400).json({ message: "Name, email, and product are required." });
  }

  const emailRegex = /\S+@\S+\.\S+/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Invalid email format." });
  }

  next();
};

module.exports = { validateInquiryData };
