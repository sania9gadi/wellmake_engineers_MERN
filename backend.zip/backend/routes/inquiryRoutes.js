const express = require('express');
const router = express.Router();

const {
  submitInquiry,
  getAllInquiries,
  getInquiryById,
  deleteInquiry
} = require('../services/inquiryServices');

const { protectRoute } = require('../middleware/authMiddleware');
const { checkAdmin } = require('../middleware/checkRole');
const { validateInquiryData } = require('../middleware/inquiryValidation');

//add inquiry
router.post('/save', protectRoute, validateInquiryData, async (req, res) => {
  try {
    const inquiry = await submitInquiry(req.body);
    res.status(201).json(inquiry);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📋 Get all inquiries — admin only
router.get('/', protectRoute, checkAdmin, async (req, res) => {
  try {
    const inquiries = await getAllInquiries();
    res.json(inquiries);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🔍 Get inquiry by ID — admin only
router.get('/:id', protectRoute, checkAdmin, async (req, res) => {
  try {
    const inquiry = await getInquiryById(req.params.id);
    if (!inquiry) {
      return res.status(404).json({ message: 'Inquiry not found' });
    }
    res.json(inquiry);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🗑️ Delete inquiry — admin only
router.delete('/:id', protectRoute, checkAdmin, async (req, res) => {
  try {
    await deleteInquiry(req.params.id);
    res.json({ message: 'Inquiry deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
