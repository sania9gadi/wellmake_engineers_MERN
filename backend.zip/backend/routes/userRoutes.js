const express = require('express');
const router = express.Router();

const { signupUser, loginUserHandler } = require('../services/userServices');


const { validateSignup, validateLogin } = require('../middleware/userValidation');

router.post('/signup', validateSignup, signupUser);

router.post('/login', validateLogin, loginUserHandler);

router.get('/signup', (req, res) => {
  res.send('Signup route working!');
});

router.get('/login', (req, res) => {
  res.send('Login route working!');
});


router.get('/', (req, res) => {
  res.send('Get all users route working!');
});

module.exports = router;
