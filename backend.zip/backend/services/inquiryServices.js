const Inquiry = require('../models/inquiry');

// Add inquiry
const submitInquiry = async (data) => {
  const inquiry = new Inquiry(data);
  return await inquiry.save();
};

// Get all inquiries
const getAllInquiries = async () => {
  return await Inquiry.find();
};

// Get inquiry by ID
const getInquiryById = async (id) => {
  return await Inquiry.findById(id);
};

// Delete inquiry by ID
const deleteInquiry = async (id) => {
  return await Inquiry.findByIdAndDelete(id);
};

module.exports = {
  submitInquiry,
  getAllInquiries,
  getInquiryById,
  deleteInquiry
};
