const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Secret for JWT (in real project, use .env file)
const JWT_SECRET = "yourSecretKey123"; 

// Register new user
async function registerUser(data) {
  const { name, email, password, role } = data;

  // Check if user already exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    throw new Error("User already exists with this email");
  }

  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const user = new User({
    name,
    email,
    password: hashedPassword,
    role: role || 'user'
  });

  return await user.save();
}

// Find user by email only (password will be compared separately)
async function findUserByEmail(email) {
  return await User.findOne({ email });
}

// Signup controller
const signupUser = async (req, res) => {
  try {
    const newUser = await registerUser(req.body);

    // Don't send password in response
    const { password, ...userData } = newUser.toObject();

    res.status(201).json({
      message: "User registered successfully",
      user: userData
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Login controller
const loginUserHandler = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await findUserByEmail(email);

    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Compare hashed passwords
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    const { password: pwd, ...userData } = user.toObject();

    res.status(200).json({
      message: "Login successful",
      token,
      user: userData
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Optional
async function getAllUsers() {
  return await User.find();
}

async function deleteUser(id) {
  return await User.findByIdAndDelete(id);
}

module.exports = {
  signupUser,
  loginUserHandler,
  registerUser,
  findUserByEmail,
  getAllUsers,
  deleteUser
};
