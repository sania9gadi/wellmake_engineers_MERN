import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';


function Navbar() {

  return (
    <>
      <nav className="navbar">
        <div className="navbar-logo">  
        </div>
        <ul className="navbar-links">
          <li><Link to="/">Home</Link></li>

          <li className="dropdown">
            <span className="dropbtn">Products ▾</span>
            <ul className="dropdown-content">
              <li><Link to="/products/cold-room">Cold Room</Link></li>
              <li><Link to="/products/walk-in-freezer">Walk-In Freezer</Link></li>
              <li><Link to="/products/puf-panel">PUF Panel</Link></li>
              <li><Link to="/products/blast-freezer">Blast Freezer</Link></li>
            </ul>
          </li>

          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/login">Login/SignUp</Link></li>
        </ul>

        
         


        

       
      </nav>
    </>
  );
}

export default Navbar;
