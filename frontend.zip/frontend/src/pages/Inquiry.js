import { useState } from "react";
import axios from "axios";
import "./Inquiry.css";

function Inquiry() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [product, setProduct] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("http://localhost:9000/api/inquiry/save", {
        name,
        email,
        product,
        message,
      });

      alert("Inquiry Submitted Successfully!");
      // Optional: Clear form
      setName("");
      setEmail("");
      setProduct("");
      setMessage("");
    } catch (err) {
      console.error("Inquiry submission failed:", err);
      alert("Failed to submit inquiry. Please try again.");
    }
  };

  return (
    <div className="inquiry-container">
      <form className="inquiry-form" onSubmit={handleSubmit}>
        <h2>Product Inquiry</h2>

        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            required
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            required
            placeholder="Your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Product</label>
          <input
            type="text"
            required
            placeholder="Product you are interested in"
            value={product}
            onChange={(e) => setProduct(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Message</label>
          <textarea
            rows="4"
            placeholder="Add any specific requirements"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
        </div>

        <button type="submit">Submit Inquiry</button>
      </form>
    </div>
  );
}

export default Inquiry;
